package com.led_on_off.led;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;

import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.os.AsyncTask;

import java.io.IOException;
import java.util.UUID;
import android.os.Handler;

import org.w3c.dom.Text;


public class ledControl extends ActionBarActivity {

    // GUI Attributes
    ImageButton Manual, Auto, Line, Discnt, Abt, Up, Down, Left, Right, Stop, Decelerate;   //BImage buttons
    EditText SpeedField;    //EditText is a text field that the user can modify via typing into it
    Button SpeedButton;     //A regular button
    TextView CurrentSpeed;  //Current speed information given by the Arduino to the Android

    //Used for bluetooth
    String address = null;
    private ProgressDialog progress;
    BluetoothAdapter myBluetooth = null;
    BluetoothSocket btSocket = null;
    private boolean isBtConnected = false;

    //Used by the thread that checks for incoming data from inputStream of btSocket
    boolean stopThread; //indicator to stop the thread or turn it on
    byte buffer[];      //if there is available info, store it here

    //SPP UUID. Look for it. Used to identify the bluetooth object to connect to
    static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        Intent newint = getIntent();
        address = newint.getStringExtra(DeviceList.EXTRA_ADDRESS); //receive the address of the bluetooth device

        //view of the ledControl
        setContentView(R.layout.activity_led_control);

        //call the widgets
        Manual = (ImageButton)findViewById(R.id.manual);
        Auto = (ImageButton)findViewById(R.id.auto);
        Line = (ImageButton)findViewById(R.id.line);
        Up = (ImageButton)findViewById(R.id.up);
        Down = (ImageButton)findViewById(R.id.down);
        Left = (ImageButton)findViewById(R.id.left);
        Right = (ImageButton)findViewById(R.id.right);
        SpeedField = (EditText) findViewById(R.id.speed_field);
        SpeedButton = (Button) findViewById(R.id.speed_button);
        Stop = (ImageButton) findViewById(R.id.stop);
        CurrentSpeed = (TextView) findViewById(R.id.current_speed);
        CurrentSpeed.setText("Movement Speed: 255 units");
        Decelerate = (ImageButton) findViewById(R.id.decelerate);


        Discnt = (ImageButton)findViewById(R.id.discnt);
        Abt = (ImageButton)findViewById(R.id.abt);

        new ConnectBT().execute(); //Call the class to connect

        //From here on until the method ends, all these codes attaches methods to buttons
        //That is, when a button is pressed, a method associated with the button activates
        Manual.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                turnOnManual();      //method to turn on
            }
        });

        Auto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                turnOnAuto();   //method to turn off
            }
        });

        Line.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                turnOnLine();   //method to turn off
            }
        });

        Up.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                moveForward();      //method to turn on
            }
        });

        Down.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                moveBackward();      //method to turn on
            }
        });

        Left.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                rotateLeft();      //method to turn on
            }
        });

        Right.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                rotateRight();      //method to turn on
            }
        });

        Discnt.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Disconnect(); //close connection
            }
        });

        SpeedButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                SubmitSpeed(); //close connection
            }
        });

        Stop.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                PressStop(); //close connection
            }
        });

        Decelerate.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Decelerate(); //close connection
            }
        });

    }

    /**
     * This method gets what is written in the user-editable text field, then sends this information to the Arduino through Bluetooth
     */
    private void SubmitSpeed() {

        //this if statement is borrowed from link below, but not the else statement
        // http://stackoverflow.com/questions/22798347/android-linking-edit-text-field-to-button
        if(TextUtils.isEmpty(SpeedField.getText().toString())) {
            //If there is nothing written, then there is no value to send to Arduino
            //So let the user know by writing in the user editable field "Please enter a number"
            SpeedField.setError("Please enter a number");
        } else {
            //If there is data in the editable text field
            //get the integer
            String number = SpeedField.getText().toString();
            //if number exceeds maximum value
            if(Integer.parseInt(number) > 255) {
                SpeedField.setError("Please enter a number between 0 and 9");
            }
            else {
                //if Bluetooth is available
                if (btSocket!=null)
                {
                    try
                    {
                        //Send a String through Bluetooth
                        btSocket.getOutputStream().write(number.toString().getBytes());
                    }
                    catch (IOException e)
                    {
                        msg("Error");
                    }
                } else {
                    //This loop is if user entered a number, but Bluetooth is not available to send over
                    msg("Bluetooth not available and data not send");
                }
            }

        }

    }

    /**
     * If stop button is pressed, send "S" to Arduino
     */
    private void PressStop() {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("S".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    /**
     * If Decelerate button is pressed, send "D" to Arduino
     */
    private void Decelerate() {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("D".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    /**
     * If Disconnect button is pressed, close the socket and stop the thread that constantly checks for incoming Bluetooth data
     */
    private void Disconnect()
    {
        if (btSocket!=null) //If the btSocket is busy
        {
            try
            {
                btSocket.close(); //close connection
                stopThread = true;  //stops the input Bluetooth thread
            }
            catch (IOException e)
            { msg("Error");}
        }
        finish(); //return to the first layout, that is, the DeviceList

    }

    /**
     * If Auto button is pressed, send "1" to Arduino
     */
    private void turnOnAuto()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("A".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    /**
     * If manual button is pressed, send "3" to Arduino
     */
    private void turnOnManual()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("C".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    /**
     * If Line button is pressed, send "2" to Arduino
     */
    private void turnOnLine()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("F".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    /**
     * If forward button is pressed, send "M" to Arduino
     */
    private void moveForward()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("M".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    /**
     * If backward button is pressed, send "B" to Arduino
     */
    private void moveBackward()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("B".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    /**
     * If left button is pressed, send "L" to Arduino
     */
    private void rotateLeft()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("L".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    /**
     * If right button is pressed, send "R" to Arduino
     */
    private void rotateRight()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("R".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    // fast way to call Toast
    private void msg(String s)
    {
        Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
    }

    /**
     * If About button is pressed, open a new intent, that is, a new page
     */
    public  void about(View v)
    {
        if(v.getId() == R.id.abt)
        {
            Intent i = new Intent(this, AboutActivity.class);
            startActivity(i);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_led_control, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //
    //

    /**
     * This function has been copied and modified from
     * https://www.allaboutcircuits.com/projects/control-an-arduino-using-your-phone/
     *
     * This function runs in the background to listen for incoming Bluetooth data and will change
     * the text
     */
    void beginListenForData()
    {
        final Handler handler = new Handler();
        stopThread = false;
        buffer = new byte[1024];
        Thread thread  = new Thread(new Runnable()
        {
            public void run()
            {
                while(!Thread.currentThread().isInterrupted() && !stopThread)
                {
                    try
                    {
                        int byteCount = btSocket.getInputStream().available();
                        if(byteCount > 0)
                        {
                            byte[] rawBytes = new byte[byteCount];
                            int numBytes = btSocket.getInputStream().read(rawBytes);
                            final String string=new String(rawBytes, 0, numBytes);
                            handler.post(new Runnable() {
                                public void run()
                                {
                                    CurrentSpeed.setText("Movement Speed: " + string + " units");
                                }
                            });

                        }
                    }
                    catch (IOException ex)
                    {
                        stopThread = true;
                    }
                }
            }
        });

        thread.start();
    }



    private class ConnectBT extends AsyncTask<Void, Void, Void>  // UI thread
    {
        private boolean ConnectSuccess = true; //if it's here, it's almost connected

        @Override
        protected void onPreExecute()
        {
            progress = ProgressDialog.show(ledControl.this, "Connecting...", "Please wait!!!");  //show a progress dialog
        }

        @Override
        protected Void doInBackground(Void... devices) //while the progress dialog is shown, the connection is done in background
        {
            try
            {
                if (btSocket == null || !isBtConnected)
                {
                    myBluetooth = BluetoothAdapter.getDefaultAdapter();//get the mobile bluetooth device
                    BluetoothDevice dispositivo = myBluetooth.getRemoteDevice(address);//connects to the device's address and checks if it's available
                    btSocket = dispositivo.createInsecureRfcommSocketToServiceRecord(myUUID);//create a RFCOMM (SPP) connection
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                    btSocket.connect();//start connection
                }
            }
            catch (IOException e)
            {
                ConnectSuccess = false;//if the try failed, you can check the exception here
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result) //after the doInBackground, it checks if everything went fine
        {
            super.onPostExecute(result);

            if (!ConnectSuccess)
            {
                msg("Connection Failed. Is it a SPP Bluetooth? Try again.");
                finish();
            }
            else
            {
                msg("Connected.");
                isBtConnected = true;
                beginListenForData();
            }
            progress.dismiss();
        }
    }
}
