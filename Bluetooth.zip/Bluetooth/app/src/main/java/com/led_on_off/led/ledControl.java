package com.led_on_off.led;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;

import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.os.AsyncTask;

import java.io.IOException;
import java.util.UUID;
import android.os.Handler;

import org.w3c.dom.Text;


public class ledControl extends ActionBarActivity {

    // Button btnOn, btnOff, btnDis;
    ImageButton Manual, Auto, Line, Discnt, Abt, Up, Down, Left, Right, Stop;
    EditText SpeedField;
    Button SpeedButton;
    String address = null;
    private ProgressDialog progress;
    BluetoothAdapter myBluetooth = null;
    BluetoothSocket btSocket = null;
    private boolean isBtConnected = false;
    boolean stopThread;
    byte buffer[];
    TextView CurrentSpeed;
    //SPP UUID. Look for it
    static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        Intent newint = getIntent();
        address = newint.getStringExtra(DeviceList.EXTRA_ADDRESS); //receive the address of the bluetooth device

        //view of the ledControl
        setContentView(R.layout.activity_led_control);

        //call the widgets
        Manual = (ImageButton)findViewById(R.id.manual);
        Auto = (ImageButton)findViewById(R.id.auto);
        Line = (ImageButton)findViewById(R.id.line);
        Up = (ImageButton)findViewById(R.id.up);
        Down = (ImageButton)findViewById(R.id.down);
        Left = (ImageButton)findViewById(R.id.left);
        Right = (ImageButton)findViewById(R.id.right);
        SpeedField = (EditText) findViewById(R.id.speed_field);
        SpeedButton = (Button) findViewById(R.id.speed_button);
        Stop = (ImageButton) findViewById(R.id.stop);
        CurrentSpeed = (TextView) findViewById(R.id.current_speed);
        CurrentSpeed.setText("Current Speed: 0 units");


        Discnt = (ImageButton)findViewById(R.id.discnt);
        Abt = (ImageButton)findViewById(R.id.abt);

        new ConnectBT().execute(); //Call the class to connect

        //commands to be sent to bluetooth
        Manual.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                turnOnManual();      //method to turn on
            }
        });

        Auto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                turnOnAuto();   //method to turn off
            }
        });

        Line.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                turnOnLine();   //method to turn off
            }
        });

        Up.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                moveForward();      //method to turn on
            }
        });

        Down.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                moveBackward();      //method to turn on
            }
        });

        Left.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                rotateLeft();      //method to turn on
            }
        });

        Right.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                rotateRight();      //method to turn on
            }
        });

        Discnt.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Disconnect(); //close connection
            }
        });

        SpeedButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                SubmitSpeed(); //close connection
            }
        });

        Stop.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                PressStop(); //close connection
            }
        });

    }

    private void SubmitSpeed() {

        //this if statement is borrowed from
        // http://stackoverflow.com/questions/22798347/android-linking-edit-text-field-to-button
        if(TextUtils.isEmpty(SpeedField.getText().toString())) {
            SpeedField.setError("Please enter a number");
        } else {
            int number = Integer.parseInt(SpeedField.getText().toString());

            if (btSocket!=null)
            {
                try
                {
                    //CHANGE ACCORDINGLY
                    String outputText = "Submitting speed: " + number;
                    btSocket.getOutputStream().write(outputText.toString().getBytes());
                }
                catch (IOException e)
                {
                    msg("Error");
                }
            }


        }

    }

    private void PressStop() {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("Stop Pressed".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    private void Disconnect()
    {
        if (btSocket!=null) //If the btSocket is busy
        {
            try
            {
                btSocket.close(); //close connection
                stopThread = true;
            }
            catch (IOException e)
            { msg("Error");}
        }
        finish(); //return to the first layout

    }

    private void turnOnAuto()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("Auto".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    private void turnOnManual()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("Manual".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    private void turnOnLine()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("Line".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    private void moveForward()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("Forward".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    private void moveBackward()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("Backward".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    private void rotateLeft()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("Left".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    private void rotateRight()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("Right".toString().getBytes());
            }
            catch (IOException e)
            {
                msg("Error");
            }
        }
    }

    // fast way to call Toast
    private void msg(String s)
    {
        Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
    }

    public  void about(View v)
    {
        if(v.getId() == R.id.abt)
        {
            Intent i = new Intent(this, AboutActivity.class);
            startActivity(i);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_led_control, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //This function has been copied and modified from
    //https://www.allaboutcircuits.com/projects/control-an-arduino-using-your-phone/
    void beginListenForData()
    {
        final Handler handler = new Handler();
        stopThread = false;
        buffer = new byte[1024];
        Thread thread  = new Thread(new Runnable()
        {
            public void run()
            {
                while(!Thread.currentThread().isInterrupted() && !stopThread)
                {
                    try
                    {
                        int byteCount = btSocket.getInputStream().available();
                        if(byteCount > 0)
                        {
                            byte[] rawBytes = new byte[byteCount];
                            int numBytes = btSocket.getInputStream().read(rawBytes);
                            final String string=new String(rawBytes, 0, numBytes);
                            handler.post(new Runnable() {
                                public void run()
                                {
                                    CurrentSpeed.setText("Current Speed: " + string + " units");
                                }
                            });

                        }
                    }
                    catch (IOException ex)
                    {
                        stopThread = true;
                    }
                }
            }
        });

        thread.start();
    }



    private class ConnectBT extends AsyncTask<Void, Void, Void>  // UI thread
    {
        private boolean ConnectSuccess = true; //if it's here, it's almost connected

        @Override
        protected void onPreExecute()
        {
            progress = ProgressDialog.show(ledControl.this, "Connecting...", "Please wait!!!");  //show a progress dialog
        }

        @Override
        protected Void doInBackground(Void... devices) //while the progress dialog is shown, the connection is done in background
        {
            try
            {
                if (btSocket == null || !isBtConnected)
                {
                    myBluetooth = BluetoothAdapter.getDefaultAdapter();//get the mobile bluetooth device
                    BluetoothDevice dispositivo = myBluetooth.getRemoteDevice(address);//connects to the device's address and checks if it's available
                    btSocket = dispositivo.createInsecureRfcommSocketToServiceRecord(myUUID);//create a RFCOMM (SPP) connection
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                    btSocket.connect();//start connection
                }
            }
            catch (IOException e)
            {
                ConnectSuccess = false;//if the try failed, you can check the exception here
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result) //after the doInBackground, it checks if everything went fine
        {
            super.onPostExecute(result);

            if (!ConnectSuccess)
            {
                msg("Connection Failed. Is it a SPP Bluetooth? Try again.");
                finish();
            }
            else
            {
                msg("Connected.");
                isBtConnected = true;
                beginListenForData();
            }
            progress.dismiss();
        }
    }
}
